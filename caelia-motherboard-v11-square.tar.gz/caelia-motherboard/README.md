# Caelia Motherboard — Real Build

This package is the real Motherboard frontend plus a matching Caelia Brain Gateway.

## Domain separation
- `https://caeliasystems.com` — Caelia public/protected home
- `https://motherboard.caeliasystems.com` — Motherboard dashboard
- `https://backend.caeliasystems.com` — backend/API

The Motherboard does **not** redirect the main Caelia domain to itself.

## What is included
- `index.html` — square-clean Motherboard UI (only Caelia's window + orbit orbs stay round)
- `assets/caelia.png` — the supplied current Caelia visual
- `backend/server.js` — v1.1 gateway (zero-dep, .env loader, request logging, allowlists)
- `backend/test.js` — smoke test: `npm test` (9 checks, all passing)
- `backend/.env.example` — secrets/config template

## Important
This is a gateway/bridge, not a replacement for independently deployed engines. It keeps the Motherboard, Brain gateway, and engines separate.

Secrets are not included in the package. Put the owner token and model/API keys in the backend environment only.

## Motherboard → backend
The frontend is configured for:
`https://backend.caeliasystems.com/api`

The gateway exposes:
- `GET /api/health` — public, uptime + modelConfigured
- `GET /api/docs` — public route list
- `GET /api/status` — live requirements (model ready/pending, brain ready, voice pending)
- `POST /api/chat {message, history?}` — model or gateway reply, saved to memory log
- `GET /api/memory?limit=50` + `POST /api/memory {text}` — Saved Facts sync
- `GET /api/teach` + `POST /api/teach {directive, source?}`
- `GET /api/failsafe` + `POST /api/failsafe {prompt}`
- `POST /api/delegate {agent, task}` — Agents switchboard bridge (Fawn, Nova, ...)
- `POST /api/engines/:id/run` — allowlist: `personal`, `qvpro` only

The Owner token is held in browser session storage only when Alicia connects from the hidden crystal admin panel. It is not hard-coded into the frontend.

## Deploy order
1. Deploy the backend gateway to your backend host and map it to `backend.caeliasystems.com`.
2. Set the environment variables from `.env.example` in the hosting provider's secret/environment settings.
3. Deploy `index.html` as the Motherboard at `motherboard.caeliasystems.com`.
4. Open the Motherboard, click the crystal/peacock control, enter the owner token, and connect.
5. Only after `/api/health` shows connected should the model key and engine bridges be tested.
