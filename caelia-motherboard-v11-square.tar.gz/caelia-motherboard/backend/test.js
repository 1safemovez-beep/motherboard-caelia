'use strict';
// Smoke test: node test.js  (optionally: PORT=8787 node test.js)
const PORT = Number(process.env.PORT || 8787);
const BASE = `http://localhost:${PORT}`;
let pass = 0, fail = 0;
async function check(name, fn) {
  try { await fn(); pass++; console.log(`ok - ${name}`); }
  catch (e) { fail++; console.log(`FAIL - ${name}: ${e.message}`); }
}
const j = async (url, opt) => {
  const r = await fetch(url, opt);
  const d = await r.json().catch(() => ({}));
  return { r, d };
};
(async () => {
  await check('health', async () => {
    const { r, d } = await j(`${BASE}/api/health`);
    if (!r.ok || !d.ok) throw new Error('health not ok');
  });
  await check('docs', async () => {
    const { r, d } = await j(`${BASE}/api/docs`);
    if (!r.ok || !d.ok) throw new Error('docs not ok');
  });
  await check('chat gateway', async () => {
    const { r, d } = await j(`${BASE}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: 'hello' }) });
    if (!r.ok || !d.ok) throw new Error('chat failed');
  });
  await check('memory save+list', async () => {
    const p = await j(`${BASE}/api/memory`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'smoke test fact' }) });
    if (p.r.status !== 201) throw new Error('memory save failed');
    const g = await j(`${BASE}/api/memory?limit=5`);
    if (!g.r.ok || !g.d.ok) throw new Error('memory list failed');
  });
  await check('teach queue+list', async () => {
    const p = await j(`${BASE}/api/teach`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ directive: 'smoke directive' }) });
    if (p.r.status !== 202) throw new Error('teach failed');
    const g = await j(`${BASE}/api/teach`);
    if (!g.r.ok) throw new Error('teach list failed');
  });
  await check('failsafe', async () => {
    const p = await j(`${BASE}/api/failsafe`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: 'smoke failsafe' }) });
    if (p.r.status !== 202) throw new Error('failsafe failed');
  });
  await check('delegate', async () => {
    const p = await j(`${BASE}/api/delegate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ agent: 'Fawn', task: 'smoke task' }) });
    if (p.r.status !== 202) throw new Error('delegate failed: ' + JSON.stringify(p.d));
  });
  await check('engines allowlist', async () => {
    const ok = await j(`${BASE}/api/engines/personal/run`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ q: 'x' }) });
    if (!ok.r.ok) throw new Error('personal engine failed');
    const bad = await j(`${BASE}/api/engines/nope/run`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    if (bad.r.status !== 404) throw new Error('unknown engine should 404');
  });
  await check('status', async () => {
    const { r, d } = await j(`${BASE}/api/status`);
    if (!r.ok || !d.ok) throw new Error('status failed');
  });
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
