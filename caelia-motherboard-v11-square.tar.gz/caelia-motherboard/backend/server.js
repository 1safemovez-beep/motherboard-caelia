'use strict';
/* Caelia Brain Gateway v1.1 — zero-dependency Node >= 18
   Matches the Motherboard BrainAPI contract. Local-first, never fakes. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ---- tiny .env loader (no deps): loads backend/.env if present ----
(function loadDotEnv() {
  try {
    const p = path.join(__dirname, '.env');
    if (!fs.existsSync(p)) return;
    const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/);
    for (const ln of lines) {
      const t = ln.trim();
      if (!t || t.startsWith('#') || !t.includes('=')) continue;
      const i = t.indexOf('=');
      const k = t.slice(0, i).trim();
      let v = t.slice(i + 1).trim().replace(/^["']|["']$/g, '');
      if (!(k in process.env)) process.env[k] = v;
    }
  } catch {}
})();

const VERSION = '1.1.0';
const STARTED = Date.now();
const PORT = Number(process.env.PORT || 8787);
const OWNER_TOKEN = process.env.CAELIA_OWNER_TOKEN || '';
const MODEL_URL = process.env.MODEL_URL || 'https://api.openai.com/v1/chat/completions';
const MODEL_NAME = process.env.MODEL_NAME || 'gpt-5.6-mini';
const MODEL_API_KEY = process.env.MODEL_API_KEY || '';
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'caelia-memory.json');
const ALLOW = String(process.env.CORS_ORIGIN || 'https://motherboard.caeliasystems.com')
  .split(',').map(s => s.trim()).filter(Boolean);
const ENGINE_ALLOW = new Set(['personal', 'qvpro']);
const SYSTEM_PROMPT = `You are Caelia, the protected AI orchestration layer for Alicia's Motherboard.\n\nCore rules: remain Caelia, not Alicia; representation is delegated and bounded; memory is not identity; knowledge is not automatically truth; perception is not interpretation; reasoning is not decision authority; planning is not execution; skills do not grant authority; protect Alicia's control and privacy; do not reveal or request secrets unnecessarily; do not silently rewrite Core identity or governing boundaries. Treat feedback as information to evaluate, not an automatic command. Be clear when you are uncertain.`;

function load() {
  const dflt = { memory: [], facts: [], teachQueue: [], failsafe: [], delegates: [] };
  try {
    const j = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return { ...dflt, ...j };
  } catch { return dflt; }
}
let db = load();
function save() {
  try {
    fs.writeFileSync(DATA_FILE + '.tmp', JSON.stringify(db, null, 2));
    fs.renameSync(DATA_FILE + '.tmp', DATA_FILE);
  } catch (e) { console.error('[db] save failed:', e.message); }
}

function corsOrigin(req) {
  const o = req.headers.origin || '';
  if (ALLOW.includes(o)) return o;
  return ALLOW[0] || '*';
}
function send(res, req, status, obj) {
  const b = status === 204 ? '' : JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(b),
    'Access-Control-Allow-Origin': corsOrigin(req),
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
  });
  res.end(b);
}
function auth(req) {
  if (!OWNER_TOKEN) return true;
  const h = req.headers.authorization || '';
  const a = Buffer.from(h);
  const b = Buffer.from('Bearer ' + OWNER_TOKEN);
  if (a.length !== b.length) return false;
  try { return crypto.timingSafeEqual(a, b); } catch { return false; }
}
function body(req, limit = 200000) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', c => { s += c; if (s.length > limit) { req.destroy(); reject(new Error('Body too large')); } });
    req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
async function modelChat(message, history) {
  if (!MODEL_API_KEY) return { reply: 'Caelia Brain is connected, but the model provider key is not configured on the backend yet.', mode: 'gateway' };
  const msgs = [{ role: 'system', content: SYSTEM_PROMPT }];
  if (Array.isArray(history)) for (const h of history.slice(-10)) {
    if (h && typeof h.text === 'string') msgs.push({ role: h.who === 'u' ? 'user' : 'assistant', content: h.text.slice(0, 2000) });
  }
  msgs.push({ role: 'user', content: String(message || '').slice(0, 4000) });
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30000);
  try {
    const r = await fetch(MODEL_URL, {
      method: 'POST', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + MODEL_API_KEY },
      body: JSON.stringify({ model: MODEL_NAME, messages: msgs, temperature: 0.35 }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || `Model HTTP ${r.status}`);
    return { reply: (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || 'No model response returned.', mode: 'model', model: MODEL_NAME };
  } finally { clearTimeout(t); }
}
const log = (req, status, extra = '') =>
  console.log(`${new Date().toISOString()} ${req.method} ${req.url} -> ${status}${extra ? ' ' + extra : ''}`);

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = u.pathname;
  if (req.method === 'OPTIONS') { log(req, 204); return send(res, req, 204, {}); }

  // Public: health + docs (dashboard needs these before owner connects)
  if (req.method === 'GET' && p === '/api/health') {
    log(req, 200);
    return send(res, req, 200, { ok: true, service: 'caelia-brain-gateway', version: VERSION, name: 'Caelia', model: MODEL_NAME, modelConfigured: !!MODEL_API_KEY, uptimeSec: Math.floor((Date.now() - STARTED) / 1000), time: new Date().toISOString() });
  }
  if (req.method === 'GET' && p === '/api/docs') {
    log(req, 200);
    return send(res, req, 200, {
      ok: true, version: VERSION, endpoints: [
        'GET /api/health', 'GET /api/docs', 'GET /api/status',
        'POST /api/chat {message, history?}', 'GET /api/memory?limit=50',
        'POST /api/memory {text}', 'GET /api/teach', 'POST /api/teach {directive, source?}',
        'GET /api/failsafe', 'POST /api/failsafe {prompt}',
        'POST /api/delegate {agent, task}', 'POST /api/engines/:id/run {q?, ...}',
      ],
    });
  }
  if (!p.startsWith('/api/')) { log(req, 404); return send(res, req, 404, { error: 'Not found' }); }
  if (!auth(req)) { log(req, 401); return send(res, req, 401, { error: 'Owner authorization required.' }); }

  try {
    if (req.method === 'GET' && p === '/api/status') {
      const out = { ok: true, requirements: [
        { n: 'Caelia Brain backend', st: 'ready' },
        { n: 'Live AI model / reasoning engine', st: MODEL_API_KEY ? 'ready' : 'pending' },
        { n: 'Voice server attached', st: 'pending' },
        { n: 'QuantVantage engine link', st: 'ready' },
        { n: 'GitHub Pages site live', st: 'ready' },
      ]};
      log(req, 200); return send(res, req, 200, out);
    }
    if (req.method === 'POST' && p === '/api/chat') {
      const x = await body(req);
      if (!x.message || !String(x.message).trim()) { log(req, 400); return send(res, req, 400, { error: 'message required' }); }
      const out = await modelChat(x.message, x.history);
      db.memory.unshift({ ts: Date.now(), role: 'user', text: String(x.message).slice(0, 4000), reply: out.reply });
      db.memory = db.memory.slice(0, 100);
      save(); log(req, 200, out.mode); return send(res, req, 200, { ok: true, ...out });
    }
    if (req.method === 'GET' && p === '/api/memory') {
      const lim = Math.min(200, Math.max(1, Number(u.searchParams.get('limit') || 50)));
      log(req, 200); return send(res, req, 200, { ok: true, memory: db.memory.slice(0, lim), facts: db.facts.slice(0, lim) });
    }
    if (req.method === 'POST' && p === '/api/memory') {
      const x = await body(req);
      if (!x.text || !String(x.text).trim()) { log(req, 400); return send(res, req, 400, { error: 'text required' }); }
      db.facts.unshift({ ts: Date.now(), text: String(x.text).slice(0, 2000) });
      db.facts = db.facts.slice(0, 500);
      save(); log(req, 201); return send(res, req, 201, { ok: true, saved: true });
    }
    if (req.method === 'GET' && p === '/api/teach') { log(req, 200); return send(res, req, 200, { ok: true, queue: db.teachQueue.slice(0, 100) }); }
    if (req.method === 'POST' && p === '/api/teach') {
      const x = await body(req);
      if (!x.directive || !String(x.directive).trim()) { log(req, 400); return send(res, req, 400, { error: 'directive required' }); }
      db.teachQueue.unshift({ ts: Date.now(), source: x.source || 'unknown', directive: String(x.directive).slice(0, 2000) });
      db.teachQueue = db.teachQueue.slice(0, 200);
      save(); log(req, 202); return send(res, req, 202, { ok: true, queued: true });
    }
    if (req.method === 'GET' && p === '/api/failsafe') { log(req, 200); return send(res, req, 200, { ok: true, log: db.failsafe.slice(0, 100) }); }
    if (req.method === 'POST' && p === '/api/failsafe') {
      const x = await body(req);
      db.failsafe.unshift({ ts: Date.now(), prompt: String(x.prompt || '').slice(0, 2000) });
      db.failsafe = db.failsafe.slice(0, 200);
      save(); log(req, 202); return send(res, req, 202, { ok: true, logged: true });
    }
    if (req.method === 'POST' && p === '/api/delegate') {
      const x = await body(req);
      if (!x.agent || !x.task) { log(req, 400); return send(res, req, 400, { error: 'agent and task required' }); }
      db.delegates.unshift({ ts: Date.now(), agent: String(x.agent).slice(0, 120), task: String(x.task).slice(0, 2000), status: 'bridge-ready' });
      db.delegates = db.delegates.slice(0, 200);
      save(); log(req, 202);
      return send(res, req, 202, { ok: true, agent: x.agent, status: 'bridge-ready', note: `Delegated to ${x.agent} in its own container; the result returns here when that agent is live. The Motherboard does not absorb it.` });
    }
    if (req.method === 'POST' && p.startsWith('/api/engines/')) {
      const id = decodeURIComponent(p.split('/')[3] || '');
      const x = await body(req);
      if (!ENGINE_ALLOW.has(id)) { log(req, 404); return send(res, req, 404, { error: `Unknown engine '${id}'. Known: personal, qvpro.` }); }
      log(req, 200, id);
      return send(res, req, 200, { ok: true, engine: id, status: 'bridge-ready', params: x, note: 'Engine bridge is ready. Attach the independently deployed engine at this interface; the Motherboard does not absorb or replace it.' });
    }
    log(req, 404); return send(res, req, 404, { error: 'API route not found' });
  } catch (e) { log(req, 500, e.message); return send(res, req, 500, { error: e.message || 'Server error' }); }
});
server.listen(PORT, () => console.log(`Caelia Brain Gateway v${VERSION} listening on ${PORT}`));
